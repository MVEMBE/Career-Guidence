<?php
/*session_start();
include('db_connection.php');

if (isset($_POST['id'])) {
    $name = $_POST['name'];

    $query = "UPDATE students SET name = ? WHERE faculty_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("sssisi", $name, $faculty_id);

    if ($stmt->execute()) {
        echo "Faculty information updated successfully!";
    } else {
        echo "Error updating Faculty: " . $stmt->error;
    }

    $stmt->close();
    
    header("Location: institute_dashboard.php?id=" . $id);
    exit;
}*/

session_start();
include('db_connection.php');

if (isset($_POST['faculty_id']) && isset($_POST['name'])) {
    $faculty_id = $_POST['faculty_id'];
    $name = $_POST['name'];

    $query = "UPDATE students SET name = ? WHERE faculty_id = ?";
    $stmt = $conn->prepare($query);
    
    $stmt->bind_param("ss", $name, $faculty_id);

    if ($stmt) {

        if ($stmt->execute()) {
            $_SESSION['message'] = "Faculty information updated successfully!";
        } else {
            $_SESSION['error'] = "Error updating faculty: " . $stmt->error;
        }

        $stmt->close();
    } else {
        $_SESSION['error'] = "Error preparing the statement: " . $conn->error;
    }

    if (isset($_POST['id'])) {
        $id = $_POST['id']; 
        header("Location: institute_dashboard.php?id=" . urlencode($id));
    } else {
        header("Location: institute_dashboard.php");
    }
    exit;
} else {
    $_SESSION['error'] = "Invalid input!";
    header("Location: institute_dashboard.php");
    exit;
}
?>
