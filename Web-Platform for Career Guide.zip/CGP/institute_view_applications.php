<?php
session_start();
/*if ($_SESSION['role'] !== 'institute') {
    header("Location: login.php");
    exit;
}*/

include('db_connection.php');

// Check if the institution_id is set in the session
/*if (!isset($_SESSION['institution_id'])) {
    die("Institution ID is not set. Please log in.");
}*/

#$institution_id = $_SESSION['institution_id'];

$query = "SELECT a.application_id, u.username, c.name as course_name, a.application_status
          FROM applications a
          JOIN users u ON a.student_id = u.user_id
          JOIN courses c ON a.course_id = c.course_id
          WHERE c.faculty_id IN (SELECT faculty_id FROM faculties WHERE institution_id = ?)";

$stmt = $conn->prepare($query);

if (!$stmt) {
    die("Statement preparation failed: " . $conn->error);
}

$stmt->bind_param("i", $institution_id);

if (!$stmt->execute()) {
    die("Execution failed: " . $stmt->error);
}

$result = $stmt->get_result();

if ($result->num_rows > 0) {
    echo "<table border='1'>";
    echo "<tr>
            <th>Application ID</th>
            <th>Student Username</th>
            <th>Course Name</th>
            <th>Application Status</th>
          </tr>";

    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$row['application_id']}</td>
                <td>{$row['username']}</td>
                <td>{$row['course_name']}</td>
                <td>{$row['application_status']}</td>
              </tr>";
    }
    echo "</table>";
} else {
    echo "No applications found.";
}

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Institution</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .avatar {
            vertical-align: middle;
            width: 80px;
            height: 80px;
            border-radius: 50%;
        }

        .ava {
            text-align: center;
        }
    </style>
</head>

<body>
    <div class="man">
        <div class="ava">
            <img src="img_avatar.png" alt="Avatar" class="avatar">
        </div>

        <header>
            <h2>View Applications</h2>
        </header>

        <div>
            <button class="cann"><a href="institute_dashboard.php">Back</a></button>
        </div>

        <table>
            <tr>
                <th>Student Name</th>
                <th>Course</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
            <?php while ($application = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?= $application['username']; ?></td>
                    <td><?= $application['course_name']; ?></td>
                    <td><?= $application['application_status']; ?></td>
                    <td>
                        <button class="canadd"><a href="update_application_status.php?application_id=<?= $application['application_id']; ?>&status=accepted">Accept</a></button>|
                        <button class="canaddy"><a href="update_application_status.php?application_id=<?= $application['application_id']; ?>&status=rejected">Reject</a></button>
                    </td>
                </tr>
            <?php } ?>
        </table>
    </div>
</body>

</html>