<?php

session_start();
include('db_connection.php');

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $query = "SELECT * FROM institutions WHERE id = ?";
    /*$stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $institution = $result->fetch_assoc();
    } else {
        echo "No data found.";
        exit;
    }*/
} else {
    echo "ID not provided.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Institute</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .avatar {
            vertical-align: middle;
            width: 80px;
            height: 80px;
            border-radius: 50%;
        }

        .ava {
            text-align: center;
        }
    </style>
</head>

<body>
    <div class="man">
        <div class="ava">
            <img src="img_avatar.png" alt="Avatar" class="avatar">
        </div>

        <header>
            <h2>Update Institute Information</h2>
        </header>

        <div>
            <button class="cann"><a href="admin_dashboard.php">Cancel</a></button>
        </div>

        <form action="update_institute.php" method="post">
            <h3>Edit Institute</h3>
            <input type="hidden" name="id" value="<?php echo htmlspecialchars($institution['id']); ?>">

            <label for="name">Name:</label>
            <input type="text" name="name" value="" placeholder="Name" required><br><br>

            <label for="type">Type:</label>
            <input type="text" name="type" value="" placeholder="Type" required><br><br>

            <label for="address">Address:</label>
            <input type="text" name="address" value="" placeholder="Address"><br><br>

            <label for="contact">Contact:</label>
            <input type="text" name="contact" value="" placeholder="Contact" required><br><br>

            <button type="submit" class="canadd">Update</button>
        </form>

    </div>
</body>

</html>