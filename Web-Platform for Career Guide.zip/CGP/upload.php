<?php

$servername = "localhost";
$username = "root";
$password = "";
$database = "cgd";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fileTmpPath = $_FILES['profile_picture']['tmp_name'];
    $fileName = $_FILES['profile_picture']['name'];
    $name = $_POST['name'];

    $uploadFileDir = __DIR__ . '/uploads/';
    if (!is_dir($uploadFileDir)) {
        mkdir($uploadFileDir, 0777, true);
    }

    $newFileName = md5(time() . $fileName) . '.' . pathinfo($fileName, PATHINFO_EXTENSION);
    $dest_path = $uploadFileDir . $newFileName;

    if (move_uploaded_file($fileTmpPath, $dest_path)) {
   
        $dbPath = 'uploads/' . $newFileName;
        $sql = "INSERT INTO profile (name, profile_picture) VALUES ('$name', '$dbPath')";
        if ($conn->query($sql) === TRUE) {
            echo json_encode(['success' => true, 'name' => $name, 'profile_picture' => $dbPath]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Database error: ' . $conn->error]);
        }
    } else {
        echo json_encode(['success' => false, 'error' => 'Error moving the uploaded file.']);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid request method.']);
}

$conn->close();
?>