<?php
header('Content-Type: application/json');

$conn = new mysqli("localhost", "root", "", "cgd");

if ($conn->connect_error) {
    die(json_encode(['status' => 'error', 'message' => 'Database connection failed.']));
}

$item_id = intval($_GET['item_id']);

$sql = "SELECT AVG(rating) as avg_rating, COUNT(*) as total_ratings 
        FROM ratings WHERE item_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $item_id);
$stmt->execute();
$result = $stmt->get_result()->fetch_assoc();

echo json_encode([
    'status' => 'success',
    'average_rating' => round($result['avg_rating'], 1),
    'total_ratings' => $result['total_ratings']
]);

$stmt->close();
$conn->close();
?>
