 <?php
session_start();

include('db_connection.php');

if (isset($_POST['login'])) {
    $email = $_POST['email'];
    if (isset($_POST['password'])) {
        $password = $_POST['password'];
    }

    $query = "SELECT * FROM users WHERE email = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['user_id'];
        $_SESSION['role'] = $user['role'];

        // Redirect based on role//
        if ($user['role'] == 'admin') {
            header("Location: admin_dashboard.php");
        } elseif ($user['role'] == 'institute') {
            header("Location: institute_dashboard.php");
        } else {
            header("Location: student_dashboard.php");
        }
    } 
    
    else {
        echo "Something went wrong when you try to LOGIN! Please try Again.";
        exit;
    }
}
?>
