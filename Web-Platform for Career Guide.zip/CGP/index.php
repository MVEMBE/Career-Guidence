<?php

$images = array_diff(scandir('images'), array('..', '.'));

$image_files = [];
foreach ($images as $image) {
    if (preg_match('/\.(jpg|jpeg|png|gif)$/i', $image)) {
        $image_files[] = 'images/' . $image;
    }
}
?>


<!DOCTYPE html>
<htm lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Career Guidance</title>
        <link rel="stylesheet" href="ind.css">
        <link rel="stylesheet" href="styles.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    </head>

    <body>

        <header>
            <main>
                <div class="main">
                    <div class="headbar">
                        <div>
                            <ul>
                                <li class="Logo">
                                    <h2>WAP</h2>
                                </li>
                            </ul>
                        </div>

                        <div>
                            <ul>
                                <li><a href="index.php"><i class="fa fa-fw fa-home"></i>Home</a></li>
                                <li><a href="admin_dashboard.php"><i class="fa fa-fw fa-wrench"></i>Admin</a></li>
                                <li><a href="institute_dashboard.php"><i class="fa fa-fw fa-building"></i>Institude</a></li>
                                <li><a href="student_dashboard.php"><i class="fa fa-fw fa-user"></i></a>Student</li>
                            </ul>
                        </div>

                        <div class="logi">
                            <ul>
                                <li><a href="login.php"><i class="fa fa-fw fa-user"></i>LogIn</a></li>
                                <li><a href="signup.php"><i class="fa fa-fw fa-user"></i>SignUp</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </main>
        </header>

        <main>
            <h1 class="fon">Welcome to the Career Guidance Web Application</h1>

            <div class="slie">
                <h3>
                    <p class="adv">Institutional Education</p>
                </h3>
            </div>

            <div class="Content">
                <h1>Student Plartform & <br><span>Learning Exploration</span> <br>Center</h1>
            </div>

            <div class="ma">
                <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
                <style>
                    .star {
                        font-size: 24px;
                        color: gray;
                        cursor: pointer;
                    }

                    .star.selected {
                        color: gold;
                    }
                </style>
                </head>

                <body>
                    <h3>Rate Us please</h3>
                    <div id="stars" data-item-id="1">
                        <span class="star" data-value="1">&#9733;</span>
                        <span class="star" data-value="2">&#9733;</span>
                        <span class="star" data-value="3">&#9733;</span>
                        <span class="star" data-value="4">&#9733;</span>
                        <span class="star" data-value="5">&#9733;</span>
                    </div>
                    <p id="feedback"></p>

                    <script>
                        $(document).ready(function() {
                            $(".star").on("mouseover", function() {
                                let value = $(this).data("value");
                                $(".star").each(function(index) {
                                    $(this).toggleClass("selected", index < value);
                                });
                            });

                            $(".star").on("mouseout", function() {
                                $(".star").removeClass("selected");
                            });

                            $(".star").on("click", function() {
                                let rating = $(this).data("value");
                                let itemId = $("#stars").data("item-id");

                                $.post("rate.php", {
                                    item_id: itemId,
                                    rating: rating
                                }, function(response) {
                                    $("#feedback").text(response.message);
                                }, "json");
                            });
                        });
                    </script>
                </body>
            </div>

            <div>
                <div class="Content">
                    <p class="Par">Students are supposed to specify their details on the
                        <br>platform to be able to track
                        their process regarding the admission application.
                        <br>your are adviced to create the login details
                        after you have registered on a particular <br>
                        university and verify all your details when ever possible.
                    </p>
                </div>
            </div>

            <div class="Content">
                <button class="Reg"><a href="signup.php">Registor Now</a></button>
            </div>

            <div class="ma">

                <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
                <style>
                    .rating-stars {
                        font-size: 24px;
                        color: gold;
                    }

                    .rating-container {
                        margin: 20px 0;
                    }
                </style>

                <h3>Rated</h3>
                <div class="rating-container">
                    <div id="rating-stars" class="rating-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</div>
                    <p id="rating-info"></p>
                </div>

                <script>
                    $(document).ready(function() {
                        const itemId = 1;
                        $.get("fetch_rating.php", {
                            item_id: itemId
                        }, function(data) {
                            if (data.status === "success") {

                                const avgRating = data.average_rating;
                                const totalRatings = data.total_ratings;

                                $("#rating-stars").html("");
                                for (let i = 1; i <= 5; i++) {
                                    $("#rating-stars").append(
                                        `<span style="color: ${i <= avgRating ? 'gold' : 'gray'}">&#9733;</span>`
                                    );
                                }

                                $("#rating-info").text(`Average Rating: ${avgRating} (${totalRatings} ratings)`);
                            } else {
                                $("#rating-info").text("Unable to load ratings.");
                            }
                        }, "json");
                    });
                </script>
            </div>

            <h3 class="fon2"><strong>Find your carrer path to higher education!</strong></h3>
            <p class="par">
                Click One below to see more...
            </p>


            <div class="conta">

                <div class="box">
                    <a href="student_dashboard.php">
                        <img src="nul 1.jpg" height="200" width="250" alt="">
                        <p class="para">National University of Lesotho</p>
                    </a>
                </div>
                <div class="box">
                    <a href="student_dashboard.php">
                        <img src="limkokwing-malaysia.jpg" height="200" width="250" alt="">
                        <p class="para">Limkokwing University of Creative Technology</p>
                    </a>
                </div>
                <div class="box">
                    <a href="student_dashboard.php">
                        <img src="National_University_of_Lesotho_Administration_Block.jpg" alt="" height="200" width="250">
                        <p class="para">Lerotholi Polytechnic</p>
                    </a>
                </div>
                <div class="box">
                    <a href="student_dashboard.php">
                        <img src="nul2.jpg" height="200" width="250" alt="">
                        <p class="para">Botho University</p>
                    </a>
                </div>
            </div>
        </main>

        <footer>
            <p>&copy; 2024 Career Guidance Platform<br>
                Privacy<br>
                Terms and Condition<br>
                About US<br>
                Contact US
            </p><br><br>
            <p>The more you Visit Us, the higher chance, <br> Be with Us all the Time and to have a chance to win $2 000.00 per month.</p>
        </footer>
        <script src="script.js"></script>
    </body>

</html>