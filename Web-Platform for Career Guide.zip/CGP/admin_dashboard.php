<?php
session_start();
if ($_SESSION['role'] !== 'admin') {
    header("Location: admin_Login.php");
    exit;
}

include('db_connection.php');

$query = "SELECT * FROM institutions";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .avatar {
            vertical-align: middle;
            width: 80px;
            height: 80px;
            border-radius: 50%;
        }

        .ava {
            text-align: center;
        }
    </style>
</head>

<body>
    <div class="man">

        <div class="ava">
            <img src="img_avatar.png" alt="Avatar" class="avatar">
        </div>

        <header>
            <h2>Admin Dashboard</h2>
        </header>

        <div class="rate">
            <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
            <style>
                .star {
                    font-size: 24px;
                    color: gray;
                    cursor: pointer;
                }

                .star.selected {
                    color: gold;
                }
            </style>
            </head>

            <body>
                <h3>Rate Us</h3>
                <div id="stars" data-item-id="1">
                    <span class="star" data-value="1">&#9733;</span>
                    <span class="star" data-value="2">&#9733;</span>
                    <span class="star" data-value="3">&#9733;</span>
                    <span class="star" data-value="4">&#9733;</span>
                    <span class="star" data-value="5">&#9733;</span>
                </div>
                <p id="feedback"></p>

                <script>
                    $(document).ready(function() {
                        $(".star").on("mouseover", function() {
                            let value = $(this).data("value");
                            $(".star").each(function(index) {
                                $(this).toggleClass("selected", index < value);
                            });
                        });

                        $(".star").on("mouseout", function() {
                            $(".star").removeClass("selected");
                        });

                        $(".star").on("click", function() {
                            let rating = $(this).data("value");
                            let itemId = $("#stars").data("item-id");

                            $.post("rate.php", {
                                item_id: itemId,
                                rating: rating
                            }, function(response) {
                                $("#feedback").text(response.message);
                            }, "json");
                        });
                    });
                </script>
            </body>
        </div>

        <div>
            <button><a href="ad_institute.php">Add New Institution</a></button>
        </div>

        <h3>Existing Institutions</h3>
        <table>
            <tr>
                <th>Name</th>
                <th>Type</th>
                <th>Address</th>
                <th>Contact</th>
                <th>Actions</th>
            </tr>
            <?php while ($institution = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?= $institution['name']; ?></td>
                    <td><?= $institution['type']; ?></td>
                    <td><?= $institution['address']; ?></td>
                    <td><?= $institution['contact']; ?></td>
                    <td class="act-but">
                        <button class="canadd"> <a href="edit_institution.php?id=<?= $institution['institution_id']; ?>">Edit</a></button>
                        <button class="canaddy"> <a href="delete_institution.php?id=<?= $institution['institution_id']; ?>">Delete</a></button>
                    </td>
                </tr>
            <?php } ?>
        </table>
    </div>


    <?php
    $query = "SELECT * FROM faculties";
    $result = $conn->query($query);
    ?>

    <div class="man">

        <h3>Existing Faculties</h3>
        <table>
            <tr>
                <th>Name</th>
            </tr>
            <?php while ($faculty = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?= $faculty['name']; ?></td>
                </tr>
            <?php } ?>
        </table>
    </div>


    <?php
    $query = "SELECT * FROM courses";
    $result = $conn->query($query);
    ?>

    <div class="man">

        <h3>Existing Courses</h3>
        <table>
            <tr>
                <th>Name</th>
            </tr>
            <?php while ($course = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?= $course['name']; ?></td>
                </tr>
            <?php } ?>
        </table>
    </div>
</body>

</html>