 <!DOCTYPE html>
 <html lang="en">

 <head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Career Guidance Platform</title>
     <link rel="stylesheet" href="losign.css">
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
     <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
 </head>

 <body>
     <main>
         <div class="wrapper">
             <span class="big-animate"></span>
             <div class="aform">
                 <div class="form-box login">
                     <h2 class="animation">Log In</h2>
                     <form action="login_process.php" method="POST">
                         <div class="input-box">
                             <input type="email" name="email" id="email" required>
                             <label for="email">Email</label>
                             <i class="bx bxs-user"></i>
                         </div>
                         <div class="input-box animation">
                             <input type="password" password="password" required value="Mv" id="myInput" onclick="myFunction()">
                             <label for="password">Password</label>
                             <i class="bx bxs-lock-alt"></i>
                         </div>
                         <button type="Submit" name="login" class="btn animation">Login</button>
                         <div class="logreg-link animation">
                             <p> Don't have an account? <a href="signup.php" class="signup-link">SignUp</a></p>
                         </div>
                     </form>
                 </div>
                 <div class="info-text login">
                     <h2>LogIn</h2>
                     <div style="margin: 24px 0;" class="ico">
                        <a href="#"><i class="fa fa-facebook"></i></a>
                        <a href="#"><i class="fa fa-twitter"></i></a>
                        <a href="#"><i class="fa fa-linkedin"></i></a>
                        <a href="#"><i class="fa fa-instagram"></i></a>
                        <a href="#"><i class="fa fa-google"></i></a>
                        <a href="#"><i class="fa fa-whatsapp"></i></a>
                    </div>
                 </div>
             </div>
         </div>
     </main>
     <script>
        function myFunction() {
            var x = document.getElementById("myInput");
            if (x.type === "password") {
                x.type = "text";
            } else {
                x.type = "password";
            }
        }
    </script>
     <script src="script.js"></script>
 </body>

 </html>