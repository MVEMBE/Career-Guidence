<?php
session_start();
if ($_SESSION['role'] !== 'student') {
    header("Location: login.php");
    exit;
}

include('db_connection.php');

$query = "SELECT * FROM courses";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Students</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .avatar {
            vertical-align: middle;
            width: 80px;
            height: 80px;
            border-radius: 50%;
        }

        .ava {
            text-align: center;
        }
    </style>
</head>

<body>
    <div class="man">

        <div class="ava">
            <img src="img_avatar.png" alt="Avatar" class="avatar">
        </div>

        <header>
            <h2>Student Dashboard</h2>
        </header>

        <div class="rate">
            <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
            <style>
                .star {
                    font-size: 24px;
                    color: gray;
                    cursor: pointer;
                }

                .star.selected {
                    color: gold;
                }
            </style>
            </head>

            <body>
                <h3>Rate Us</h3>
                <div id="stars" data-item-id="1">
                    <span class="star" data-value="1">&#9733;</span>
                    <span class="star" data-value="2">&#9733;</span>
                    <span class="star" data-value="3">&#9733;</span>
                    <span class="star" data-value="4">&#9733;</span>
                    <span class="star" data-value="5">&#9733;</span>
                </div>
                <p id="feedback"></p>

                <script>
                    $(document).ready(function() {
                        $(".star").on("mouseover", function() {
                            let value = $(this).data("value");
                            $(".star").each(function(index) {
                                $(this).toggleClass("selected", index < value);
                            });
                        });

                        $(".star").on("mouseout", function() {
                            $(".star").removeClass("selected");
                        });

                        $(".star").on("click", function() {
                            let rating = $(this).data("value");
                            let itemId = $("#stars").data("item-id");

                            $.post("rate.php", {
                                item_id: itemId,
                                rating: rating
                            }, function(response) {
                                $("#feedback").text(response.message);
                            }, "json");
                        });
                    });
                </script>
            </body>
        </div>

        <div>
            <button><a href="view_admissions.php">View Admissions</a></button>
        </div>

        <h3>Available Courses</h3>
        <table>
            <tr>
                <th>Course Name</th>
                <th>Action</th>
            </tr>
            <?php while ($course = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?= $course['name']; ?></td>
                    <td>
                        <button><a href="apply_for_course.php?course_id=<?= $course['course_id']; ?>">Apply</a></button>
                    </td>
                </tr>
            <?php } ?>
        </table>
    </div>
</body>

</html>