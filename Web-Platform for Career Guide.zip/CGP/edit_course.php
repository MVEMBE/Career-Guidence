<?php

session_start();
include('db_connection.php');

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $query = "SELECT * FROM courses WHERE id = ?";
    #$stmt = $conn->prepare($query);
    #$stmt->bind_param("i", $id);
    #$stmt->execute();
    #$result = $stmt->get_result();

    /*if ($result->num_rows > 0) {
        $course = $result->fetch_assoc();
    } else {
        echo "No data found.";
        exit;
    }*/
} else {
    echo "ID not provided.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Course</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .avatar {
            vertical-align: middle;
            width: 80px;
            height: 80px;
            border-radius: 50%;
        }

        .ava {
            text-align: center;
        }
    </style>
</head>

<body>
    <div class="man">
        <div class="ava">
            <img src="img_avatar.png" alt="Avatar" class="avatar">
        </div>

        <header>
            <h2>Update Course Information</h2>
        </header>

        <div>
            <button class="cann"><a href="institute_dashboard.php">Cancel</a></button>
        </div>

        <form action="update_course.php" method="post">
            <h3>Edit Course</h3>
            <input type="hidden" name="id" value="<?php echo htmlspecialchars($course['id']); ?>">

            <label for="name">Name:</label>
            <input type="text" name="name" value="" placeholder="Name" required><br><br>

            <button type="submit" class="canadd">Update</button>
        </form>

    </div>
</body>

</html>