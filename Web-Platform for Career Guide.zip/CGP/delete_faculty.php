
<?php
session_start();
/*if ($_SESSION['role'] !== 'institute') {
    header("Location: login.php");
    exit;
}*/

include('db_connection.php');

if (isset($_GET['id'])) {
    $faculty_id = $_GET['id'];

    $query = "SELECT COUNT(*) FROM courses WHERE faculty_id = ?";

    if ($num_courses > 0) {
        echo "Cannot delete this faculty as it has linked courses.";
        exit;
    }

    $query = "DELETE FROM faculties WHERE faculty_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $faculty_id);

    if ($stmt->execute()) {
        echo "Action successful!";
        header("Location: institute_dashboard.php");
    }else {
        echo "Something went wrong, please try again.";
        exit;
    }
}

